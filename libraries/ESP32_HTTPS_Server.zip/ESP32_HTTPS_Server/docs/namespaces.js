var namespaces =
[
    [ "httpsserver", "namespacehttpsserver.html", null ]
];