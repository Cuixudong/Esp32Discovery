var classhttpsserver_1_1HTTPHeaders =
[
    [ "HTTPHeaders", "classhttpsserver_1_1HTTPHeaders.html#a586bae488375784fd1d0d526814fbecd", null ],
    [ "~HTTPHeaders", "classhttpsserver_1_1HTTPHeaders.html#a3742daed3064d5f0448ce71ccded60c5", null ],
    [ "clearAll", "classhttpsserver_1_1HTTPHeaders.html#a5a6a4d66dfa4aca9242a577b8fb72b5c", null ],
    [ "get", "classhttpsserver_1_1HTTPHeaders.html#a0e55f97b11fd8b57d8dda20a7b1e897e", null ],
    [ "getAll", "classhttpsserver_1_1HTTPHeaders.html#a820ae847d12fafcb6216280c9f6730f2", null ],
    [ "getValue", "classhttpsserver_1_1HTTPHeaders.html#ac671fedebc1aef75641cf1ab0a11f58c", null ],
    [ "set", "classhttpsserver_1_1HTTPHeaders.html#a8cb2c7dedbd7a70fe8735fdc7e9d9318", null ]
];