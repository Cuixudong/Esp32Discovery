var searchData=
[
  ['discard',['discard',['../classhttpsserver_1_1WebsocketInputStreambuf.html#a7873057efc443e33e210d09cca03565c',1,'httpsserver::WebsocketInputStreambuf']]],
  ['discardrequestbody',['discardRequestBody',['../classhttpsserver_1_1HTTPRequest.html#a4cf913006633555d142f23ab7fa5e876',1,'httpsserver::HTTPRequest']]]
];
