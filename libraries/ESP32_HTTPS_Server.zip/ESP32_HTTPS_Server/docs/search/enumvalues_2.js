var searchData=
[
  ['websocket',['WEBSOCKET',['../namespacehttpsserver.html#a2dcb10ebf7a4b0511b3ca52d4af865ffa0d9fe62d6ba8d8d9e4e4245df77fdfac',1,'httpsserver']]]
];
