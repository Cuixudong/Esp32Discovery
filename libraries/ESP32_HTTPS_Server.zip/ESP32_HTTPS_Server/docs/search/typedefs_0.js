var searchData=
[
  ['httpscallbackfunction',['HTTPSCallbackFunction',['../namespacehttpsserver.html#a2c7d94f7c5a324c8ddc602d4f28eccf8',1,'httpsserver']]],
  ['httpsmiddlewarefunction',['HTTPSMiddlewareFunction',['../namespacehttpsserver.html#a52016b2f3eb2452288ddae01a9f5633b',1,'httpsserver']]]
];
