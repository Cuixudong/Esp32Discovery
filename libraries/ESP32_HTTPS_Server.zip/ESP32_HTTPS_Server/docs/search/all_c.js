var searchData=
[
  ['onclose',['onClose',['../classhttpsserver_1_1WebsocketHandler.html#a9a60cb5f4db6d0267b6114f06aa45116',1,'httpsserver::WebsocketHandler']]],
  ['onerror',['onError',['../classhttpsserver_1_1WebsocketHandler.html#a18f912105b6c238dadd1f2d771cff1bc',1,'httpsserver::WebsocketHandler']]],
  ['onmessage',['onMessage',['../classhttpsserver_1_1WebsocketHandler.html#a8c0c9881bd80ec13215a64723d37f28d',1,'httpsserver::WebsocketHandler']]]
];
