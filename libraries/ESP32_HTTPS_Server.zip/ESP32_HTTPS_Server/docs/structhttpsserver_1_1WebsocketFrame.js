var structhttpsserver_1_1WebsocketFrame =
[
    [ "fin", "structhttpsserver_1_1WebsocketFrame.html#a62b8e7f4b3db863b8f2bb5ff00b54127", null ],
    [ "len", "structhttpsserver_1_1WebsocketFrame.html#ad8cbbbc43626d2fef5b23d321f6f29c2", null ],
    [ "mask", "structhttpsserver_1_1WebsocketFrame.html#ade6f36bfd981f63e9a48dc8843d69276", null ],
    [ "opCode", "structhttpsserver_1_1WebsocketFrame.html#a8735010eee4f03884e6cabf73ddbecbd", null ],
    [ "rsv1", "structhttpsserver_1_1WebsocketFrame.html#a61d1bbb49a5f8ac31e4f3efc3eaccd81", null ],
    [ "rsv2", "structhttpsserver_1_1WebsocketFrame.html#a8d77f3e1a7b2c14f3f840502eacd8f0e", null ],
    [ "rsv3", "structhttpsserver_1_1WebsocketFrame.html#a67e3eade4fb72069fcbb4d6873626bd2", null ]
];