var classhttpsserver_1_1WebsocketNode =
[
    [ "WebsocketNode", "classhttpsserver_1_1WebsocketNode.html#a3785ad6bab14e30349279db6ab3c895e", null ],
    [ "~WebsocketNode", "classhttpsserver_1_1WebsocketNode.html#a3282e55407c4fe7230f6b7d9b052cf8a", null ],
    [ "getMethod", "classhttpsserver_1_1WebsocketNode.html#a84835327f87ecf8eddfa4a4d651ff3c5", null ],
    [ "newHandler", "classhttpsserver_1_1WebsocketNode.html#ae1795c2d33143f70f0426f2c84d39d4e", null ]
];